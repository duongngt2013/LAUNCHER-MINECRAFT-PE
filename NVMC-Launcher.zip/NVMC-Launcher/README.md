# NVMC Launcher 1.0-alpha1

Android launcher prototype for Minecraft Bedrock.

## What works
- Android 8.0+ (minSdk 26), Java-only APK, so the launcher itself is not restricted to one CPU ABI.
- Detects the official Minecraft Bedrock package `com.mojang.minecraftpe`.
- Launches Minecraft if installed.
- Lightweight native Android UI.
- Shows Android API, primary ABI, total RAM and available RAM.
- Settings screens are prototype UI.

## Important limitations
This alpha does NOT install Minecraft, include Minecraft files, create isolated Bedrock runtime instances, authenticate Microsoft accounts, change Bedrock renderer/VSync/resolution, or edit game memory limits. Android does not provide a public API for a third-party launcher to force these settings in another app.
Bedrock version management and pack/world management are planned but not implemented yet.

## Build
Open this folder in Android Studio with Android Gradle Plugin 8.7.3 and compile SDK 35, then Build > Build APK(s).
The generated APK should be under `app/build/outputs/apk/debug/`.

For a command-line build, use Gradle 8.9 with JDK 17 and Android SDK platform 35 installed:
`gradle assembleDebug`

## Package
`com.nvmc.launcher`


## GitHub Actions build
The included `.github/workflows/build.yml` builds a debug APK on pushes to `main` or manually through Actions > Build NVMC Launcher APK > Run workflow. Download the `NVMC-Launcher-debug` artifact from the completed run.
