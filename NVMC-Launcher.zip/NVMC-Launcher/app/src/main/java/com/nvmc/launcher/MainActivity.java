package com.nvmc.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String MC_PACKAGE = "com.mojang.minecraftpe";
    private LinearLayout root, content;
    private String page = "home";
    private int accent = Color.rgb(73, 190, 190);
    private final String[] sections = {
        "Hình ảnh và trình kết xuất", "Tùy chỉnh điều khiển",
        "Môi trường chạy Bedrock", "Các cài đặt khác", "Cài đặt thử nghiệm"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(23,23,23));
        getWindow().setNavigationBarColor(Color.rgb(12,12,12));
        build("home");
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(dp(4),dp(5),dp(4),dp(5)); return v;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16),dp(10),dp(16),dp(10)); return l;
    }
    private void build(String p) {
        page=p; root=column(); root.setBackgroundColor(Color.rgb(24,24,24));
        setContentView(root);
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("NVMC",22,Color.WHITE,true); top.addView(brand,new LinearLayout.LayoutParams(0,dp(54),1));
        TextView home=text("⌂",30,Color.WHITE,true); home.setGravity(Gravity.CENTER);
        top.addView(home,new LinearLayout.LayoutParams(dp(48),dp(54)));
        home.setOnClickListener(v->build("home")); root.addView(top);
        View line=new View(this); line.setBackgroundColor(accent); root.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
        ScrollView scroll=new ScrollView(this); content=column(); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if ("home".equals(p)) homePage(); else settingsPage(p);
        TextView footer=text("NVMC Launcher 1.0-alpha1  •  ARM/Android 8+",11,0xff999999,false);
        footer.setGravity(Gravity.CENTER); root.addView(footer);
    }
    private void homePage() {
        content.addView(text("BEDROCK LAUNCHER",13,accent,true));
        content.addView(text("Minecraft Bedrock",25,Color.WHITE,true));
        boolean installed=isInstalled();
        TextView status=text(installed ? "● Minecraft PE đã được phát hiện" : "● Chưa phát hiện Minecraft PE",14,installed?0xff80cbc4:0xffffcc80,true);
        content.addView(status);
        Button launch=button(installed?"KHỞI CHẠY MINECRAFT":"KIỂM TRA LẠI");
        content.addView(launch); launch.setOnClickListener(v->{ if(isInstalled()) launchGame(); else new AlertDialog.Builder(this).setMessage("Bạn cần cài Minecraft Bedrock chính thức trên thiết bị trước. NVMC không chứa game engine hoặc bộ cài Minecraft.").setPositiveButton("Đã hiểu",null).show(); });
        content.addView(text("CÀI ĐẶT",13,accent,true));
        for(String s:sections) {
            TextView item=text("⚙   "+s+"     ›",17,Color.WHITE,true);
            item.setBackgroundColor(0xff303030); item.setPadding(dp(14),dp(17),dp(14),dp(17));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(8); content.addView(item,lp);
            item.setOnClickListener(v->build(s));
        }
        content.addView(text("Phiên bản mục tiêu: Bedrock 1.21.114 → mới nhất. Bản alpha hiện chỉ mở game đã cài; quản lý/cài phiên bản chưa được triển khai.",12,0xffbbbbbb,false));
    }
    private void settingsPage(String p) {
        TextView back=text("‹   Quay lại",17,Color.WHITE,true); content.addView(back); back.setOnClickListener(v->build("home"));
        content.addView(text(p.toUpperCase(Locale.ROOT),14,accent,true));
        if(p.equals(sections[0])) {
            content.addView(text("Resolution scale (giao diện thử nghiệm)",16,Color.WHITE,true));
            SeekBar seek=new SeekBar(this); seek.setMax(75); seek.setProgress(25); content.addView(seek);
            content.addView(text("Lưu ý: thanh này hiện chỉ lưu lựa chọn trong giao diện, chưa thay đổi độ phân giải của Minecraft.",12,0xffbbbbbb,false));
            switchRow("Performance mode (không can thiệp nhiệt/ép xung)",false);
            switchRow("Alternative renderer (chưa khả dụng nếu game không cung cấp)",false);
            switchRow("VSync (chỉ có tác dụng nếu game hỗ trợ)",false);
        } else if(p.equals(sections[1])) {
            content.addView(text("Điều khiển Bedrock được chỉnh trong cài đặt của chính Minecraft. NVMC chưa thể sửa trực tiếp layout điều khiển.",14,0xffcccccc,false));
            button("MỞ MINECRAFT").setOnClickListener(v->launchGame());
        } else if(p.equals(sections[2])) {
            info("Android API",String.valueOf(Build.VERSION.SDK_INT));
            info("ABI",Build.SUPPORTED_ABIS.length>0?Build.SUPPORTED_ABIS[0]:"Unknown");
            info("RAM thiết bị",ramTotal()+" MB");
            info("RAM khả dụng",ramAvailable()+" MB");
            info("Minecraft package",isInstalled()?"Đã cài":"Chưa cài");
            info("Renderer", "Đọc thông tin OpenGL chi tiết chưa được bật trong alpha");
            content.addView(text("Ngân sách 520 MB chỉ là mục tiêu tham khảo. Android/game tự quyết định bộ nhớ; launcher không thể ép Minecraft dùng đúng mức này.",12,0xffffcc80,false));
        } else if(p.equals(sections[3])) {
            switchRow("Verify game files (chưa triển khai)",true);
            switchRow("Fast game startup (chưa triển khai)",false);
            switchRow("Kiểm tra phiên bản khi mở launcher",true);
            content.addView(text("Nguồn game: cài đặt chính thức từ Google Play. Không tải APK game từ nguồn không xác minh.",12,0xffbbbbbb,false));
        } else {
            switchRow("Ghi log chẩn đoán",true);
            switchRow("Thử nghiệm giảm tải giao diện",false);
            switchRow("Force English (chỉ giao diện launcher)",false);
            content.addView(text("Các công tắc thử nghiệm ở bản alpha chưa thay đổi engine Bedrock.",12,0xffffcc80,false));
        }
    }
    private void switchRow(String label, boolean checked) {
        Switch s=new Switch(this); s.setText(label); s.setTextColor(Color.WHITE); s.setTextSize(14); s.setChecked(checked);
        s.setPadding(0,dp(10),0,dp(10)); content.addView(s);
        s.setOnCheckedChangeListener((b,c)->Toast.makeText(this,"Bản alpha: tùy chọn giao diện, chưa áp dụng vào game.",Toast.LENGTH_SHORT).show());
    }
    private void info(String k,String v) { LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.addView(text(k,12,0xffaaaaaa,false)); row.addView(text(v,17,Color.WHITE,true)); content.addView(row); }
    private Button button(String label) {
        Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff249fba));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(58)); lp.topMargin=dp(12); lp.bottomMargin=dp(16); b.setLayoutParams(lp); return b;
    }
    private boolean isInstalled() {
        try { getPackageManager().getPackageInfo(MC_PACKAGE,0); return true; }
        catch(Exception e) { return false; }
    }
    private void launchGame() {
        try {
            Intent i=getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);
            if(i==null) throw new Exception("Không tìm thấy màn hình khởi chạy");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
        } catch(Exception e) {
            new AlertDialog.Builder(this).setTitle("Không thể mở Minecraft").setMessage(e.getMessage()).setPositiveButton("OK",null).show();
        }
    }
    private long ramTotal() {
        try { ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m); return m.totalMem/1048576; } catch(Exception e){return -1;}
    }
    private long ramAvailable() {
        try { ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo(); ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m); return m.availMem/1048576; } catch(Exception e){return -1;}
    }
}
