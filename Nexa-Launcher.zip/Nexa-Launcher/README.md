# Nexa Launcher — Android ARMv7

Nexa Launcher is a native Java Android project targeting 32-bit ARMv7 devices, with Android 8.1 (API 27) as the minimum OS.

## Build

- JDK: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Compile SDK: 35
- Target SDK: 28
- ABI: `armeabi-v7a` only

Run `gradle assembleDebug` from this folder. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions is manual-only (`workflow_dispatch`). It does not build on push.

## Implemented in this development build

- Nexa Launcher branding and app icon.
- Native dark UI suitable for older Android devices.
- Local instance metadata: create and delete named profiles, choose a Bedrock version/channel and associate a local account-profile label.
- Local account-profile labels and selected-profile state.
- Version catalog client that can fetch an HTTPS JSON manifest, cache it and split `release` and `beta` entries. Entries below 1.21.114 are filtered out.
- Detection and launch of the official Minecraft Bedrock Android package when it is already installed.

## Version manifest format

Configure the HTTPS manifest URL in Versions. Expected JSON:

```json
{
  "schema": 1,
  "versions": [
    {
      "version": "1.21.114",
      "channel": "release",
      "releasedAt": "2025-10-16",
      "changelogUrl": "https://example.org/changelog"
    },
    {
      "version": "26.70.21",
      "channel": "beta",
      "releasedAt": "2026-10-01",
      "changelogUrl": "https://example.org/beta-notes"
    }
  ]
}
```

`channel` must be `release` or `beta`. This build reads metadata only; it does not download Minecraft binaries from arbitrary websites.

## Important limitations — not yet implemented

- Microsoft OAuth login and secure token storage are not implemented. The account screen currently stores local profile labels only; it does not authenticate a Microsoft account or switch the account inside Minecraft.
- Bedrock runtime isolation / portable execution is not implemented. Ordinary Android apps cannot execute an uninstalled APK directly from their private data directory. Android's package installer and package/signature rules apply. This build launches the official Minecraft package only if installed.
- Multiple instance entries are metadata profiles, not independent installed copies of Bedrock. Android's package model does not provide ordinary third-party apps with isolated parallel copies of another app.
- No Minecraft game files or APK are bundled.
- No third-party website scraping adapter, trusted binary delivery, checksum/signature verification pipeline, or automatic game installer is included yet.

These are explicit integration tasks, not features represented as already working.
