package com.nexa.launcher.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.nexa.launcher.model.GameInstance;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;
import java.util.List;

public class InstanceStore {
    private final SharedPreferences prefs;
    public InstanceStore(Context c) { prefs=c.getSharedPreferences("nexa_instances",Context.MODE_PRIVATE); }
    public List<GameInstance> all() {
        List<GameInstance> out=new ArrayList<>();
        try { JSONArray a=new JSONArray(prefs.getString("items","[]")); for(int i=0;i<a.length();i++) out.add(GameInstance.fromJson(a.getJSONObject(i))); }
        catch(Exception ignored) { }
        return out;
    }
    public void save(GameInstance item) {
        List<GameInstance> list=all(); boolean replaced=false;
        for(int i=0;i<list.size();i++) if(list.get(i).id.equals(item.id)){list.set(i,item);replaced=true;break;}
        if(!replaced) list.add(item); write(list);
    }
    public void delete(String id) { List<GameInstance> list=all(); for(int i=list.size()-1;i>=0;i--) if(list.get(i).id.equals(id)) list.remove(i); write(list); }
    private void write(List<GameInstance> list) {
        JSONArray a=new JSONArray(); try { for(GameInstance i:list) a.put(i.toJson()); } catch(JSONException ignored) { }
        prefs.edit().putString("items",a.toString()).apply();
    }
}
