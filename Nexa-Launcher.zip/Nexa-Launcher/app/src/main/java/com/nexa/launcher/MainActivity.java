package com.nexa.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.nexa.launcher.data.AccountStore;
import com.nexa.launcher.data.InstanceStore;
import com.nexa.launcher.data.VersionRepository;
import com.nexa.launcher.model.GameInstance;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String MC_PACKAGE="com.mojang.minecraftpe";
    private static final int BG=Color.rgb(7,13,32), PANEL=Color.rgb(17,29,58), CYAN=Color.rgb(0,217,245), WHITE=Color.WHITE, MUTED=Color.rgb(166,185,211);
    private LinearLayout root,body;
    private AccountStore accounts;
    private InstanceStore instances;
    private VersionRepository versions;
    private String page="home";

    @Override public void onCreate(Bundle b){super.onCreate(b);accounts=new AccountStore(this);instances=new InstanceStore(this);versions=new VersionRepository(this);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);show("home");}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView label(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(3),dp(5),dp(3),dp(5));return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(12),dp(16),dp(12));return l;}
    private void show(String p){
        page=p;root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=label("NEXA",24,WHITE,true);top.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView sub=label("LAUNCHER",11,CYAN,true);top.addView(sub);root.addView(top);
        View line=new View(this);line.setBackgroundColor(CYAN);root.addView(line,new LinearLayout.LayoutParams(-1,dp(2)));
        ScrollView scroll=new ScrollView(this);body=vertical();scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if("home".equals(p))home();else if("accounts".equals(p))accountPage();else if("instances".equals(p))instancePage();else if("versions".equals(p))versionPage();else if("settings".equals(p))settingsPage();
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[][] tabs={{"HOME","home"},{"ACCOUNTS","accounts"},{"INSTANCES","instances"},{"VERSIONS","versions"}};
        for(String[] t:tabs){Button b=smallButton(t[0]);nav.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));b.setOnClickListener(v->show(t[1]));}root.addView(nav);
    }
    private void home(){
        TextView hero=label("BEDROCK MANAGEMENT",12,CYAN,true);body.addView(hero);
        body.addView(label("Your worlds. Your profiles.\nOne launcher.",25,WHITE,true));
        card("GAME STATUS",(isInstalled()?"Minecraft Bedrock detected":"Minecraft Bedrock is not installed")+"\nAndroid API "+android.os.Build.VERSION.SDK_INT+" · "+(android.os.Build.SUPPORTED_ABIS.length>0?android.os.Build.SUPPORTED_ABIS[0]:"Unknown"));
        Button play=primary("PLAY SELECTED INSTANCE");body.addView(play);play.setOnClickListener(v->playSelected());
        Button create=secondary("＋  CREATE GAME INSTANCE");body.addView(create);create.setOnClickListener(v->createInstanceDialog());
        card("YOUR INSTANCES",instances.all().isEmpty()?"No instances yet. Create your first profile.":instances.all().size()+" saved game instance(s)");
        Button a=secondary("MANAGE ACCOUNTS");body.addView(a);a.setOnClickListener(v->show("accounts"));
        Button ver=secondary("BROWSE RELEASE / BETA VERSIONS");body.addView(ver);ver.setOnClickListener(v->show("versions"));
        body.addView(label("Nexa ARMv7 · Early development build",11,MUTED,false));
    }
    private void accountPage(){
        body.addView(label("ACCOUNT PROFILES",20,WHITE,true));
        body.addView(label("This build stores local profile labels only. Microsoft OAuth sign-in and secure token storage are not connected yet; these entries do not sign you into Minecraft.",13,0xffffcc80,false));
        List<AccountStore.Account> list=accounts.all();
        if(list.isEmpty())body.addView(label("No profiles added.",14,MUTED,false));
        for(AccountStore.Account a:list){LinearLayout row=cardBox();row.addView(label(a.name+(a.id.equals(accounts.selected())?"  ✓ SELECTED":""),16,WHITE,true));LinearLayout actions=new LinearLayout(this);Button choose=smallButton("SELECT"),del=smallButton("DELETE");actions.addView(choose);actions.addView(del);row.addView(actions);choose.setOnClickListener(v->{accounts.select(a.id);show("accounts");});del.setOnClickListener(v->{accounts.remove(a.id);show("accounts");});body.addView(row);}
        Button add=primary("＋ ADD LOCAL PROFILE");body.addView(add);add.setOnClickListener(v->{EditText input=edit("Profile name");new AlertDialog.Builder(this).setTitle("Add profile").setView(input).setPositiveButton("Save",(d,w)->{String s=input.getText().toString().trim();if(!s.isEmpty())accounts.add(s);show("accounts");}).setNegativeButton("Cancel",null).show();});
    }
    private void instancePage(){
        body.addView(label("GAME INSTANCES",20,WHITE,true));body.addView(label("Each entry stores its own profile metadata. Android Bedrock package isolation is not available to ordinary launchers, so this is not yet a separate installed game copy.",13,MUTED,false));
        for(GameInstance g:instances.all()){LinearLayout box=cardBox();box.addView(label(g.name,18,WHITE,true));box.addView(label(g.channel.toUpperCase()+" · "+g.version,13,CYAN,true));String acc="No account profile";for(AccountStore.Account a:accounts.all())if(a.id.equals(g.accountId))acc=a.name;box.addView(label("Selected profile: "+acc,12,MUTED,false));LinearLayout actions=new LinearLayout(this);Button play=smallButton("PLAY"),remove=smallButton("DELETE");actions.addView(play);actions.addView(remove);box.addView(actions);play.setOnClickListener(v->play(g));remove.setOnClickListener(v->{instances.delete(g.id);show("instances");});body.addView(box);}
        Button add=primary("＋ CREATE INSTANCE");body.addView(add);add.setOnClickListener(v->createInstanceDialog());
    }
    private void createInstanceDialog(){
        LinearLayout form=vertical();EditText name=edit("Instance name");EditText version=edit("Version (e.g. 1.21.114)");version.setText("1.21.114");Spinner channel=new Spinner(this);String[] channels={"Release","Beta / Preview"};channel.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,channels));Spinner account=new Spinner(this);List<AccountStore.Account> ac=accounts.all();String[] names=new String[ac.size()+1];names[0]="No account profile";for(int i=0;i<ac.size();i++)names[i+1]=ac.get(i).name;account.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));form.addView(name);form.addView(version);form.addView(label("Channel",13,MUTED,true));form.addView(channel);form.addView(label("Account profile",13,MUTED,true));form.addView(account);
        new AlertDialog.Builder(this).setTitle("Create game instance").setView(form).setPositiveButton("Create",(d,w)->{String n=name.getText().toString().trim(),v=version.getText().toString().trim();if(n.isEmpty()||v.isEmpty()){toast("Enter an instance name and version.");return;}String aid=account.getSelectedItemPosition()==0?"":ac.get(account.getSelectedItemPosition()-1).id;instances.save(new GameInstance(UUID.randomUUID().toString(),n,v,channel.getSelectedItemPosition()==0?"release":"beta",aid));show("instances");}).setNegativeButton("Cancel",null).show();
    }
    private void versionPage(){
        body.addView(label("VERSION CATALOG",20,WHITE,true));body.addView(label("Minimum supported catalog version: 1.21.114. Release and Beta are kept separate.",13,MUTED,false));
        Button source=secondary("CONFIGURE VERSION MANIFEST URL");body.addView(source);source.setOnClickListener(v->{EditText e=edit("https://your-domain/versions.json");e.setText(versions.source());new AlertDialog.Builder(this).setTitle("Version source").setMessage("Enter an HTTPS JSON manifest endpoint. Website scraping adapters / official source verification are not configured in this build.").setView(e).setPositiveButton("Save",(d,w)->{versions.setSource(e.getText().toString());loadVersions();}).setNegativeButton("Cancel",null).show();});
        Button refresh=primary("SYNC VERSIONS");body.addView(refresh);refresh.setOnClickListener(v->loadVersions());
        showVersions(versions.cached());
    }
    private void loadVersions(){toast("Syncing version catalog…");versions.refresh((list,error)->runOnUiThread(()->{if(error!=null)toast(error);show("versions");}));}
    private void showVersions(List<VersionRepository.Version> list){
        body.addView(label("OFFICIAL RELEASE",15,CYAN,true));boolean any=false;for(VersionRepository.Version v:list)if(v.channel.equals("release")){body.addView(label(v.number+(v.date.isEmpty()?"":" · "+v.date),15,WHITE,false));any=true;}if(!any)body.addView(label("No Release entries cached.",12,MUTED,false));
        body.addView(label("BETA / PREVIEW",15,CYAN,true));any=false;for(VersionRepository.Version v:list)if(v.channel.equals("beta")){body.addView(label(v.number+(v.date.isEmpty()?"":" · "+v.date),15,WHITE,false));any=true;}if(!any)body.addView(label("No Beta entries cached.",12,MUTED,false));
    }
    private void settingsPage(){body.addView(label("SETTINGS",20,WHITE,true));card("PLATFORM","Android ARMv7 (32-bit) build · minimum Android 8.1 / API 27");card("GAME RUNTIME","This prototype can launch the official Minecraft app when installed. It cannot execute an uninstalled APK from private storage.");card("NEXT INTEGRATIONS","Microsoft OAuth, trusted version catalog service, verified game delivery and Android-supported installation flow.");}
    private void playSelected(){List<GameInstance> all=instances.all();if(all.isEmpty()){toast("Create an instance first.");show("instances");return;}play(all.get(0));}
    private void play(GameInstance g){if(!isInstalled()){new AlertDialog.Builder(this).setTitle("Minecraft is not installed").setMessage("Android requires an APK to be installed through its package installer before it can be launched. Nexa cannot run an uninstalled Bedrock APK directly from its private data folder. This build does not include Minecraft.").setPositiveButton("OK",null).show();return;}Intent i=getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);if(i==null){toast("Minecraft launch activity was not found.");return;}startActivity(i);toast("Opening Minecraft. The selected Nexa profile is not yet injected into Minecraft sign-in.");}
    private boolean isInstalled(){try{getPackageManager().getPackageInfo(MC_PACKAGE,0);return true;}catch(PackageManager.NameNotFoundException e){return false;}}
    private void card(String title,String value){LinearLayout b=cardBox();b.addView(label(title,11,CYAN,true));b.addView(label(value,14,WHITE,false));body.addView(b);}
    private LinearLayout cardBox(){LinearLayout b=vertical();b.setBackgroundColor(PANEL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);b.setLayoutParams(p);return b;}
    private Button primary(String s){Button b=button(s,CYAN,BG);return b;}
    private Button secondary(String s){return button(s,PANEL,WHITE);}
    private Button smallButton(String s){return button(s,PANEL,CYAN);}
    private Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(fg);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(bg));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.topMargin=dp(5);p.bottomMargin=dp(5);b.setLayoutParams(p);return b;}
    private EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);return e;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
