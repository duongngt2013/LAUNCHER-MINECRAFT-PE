package com.nexa.launcher.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Stores local account labels only. OAuth tokens/passwords are deliberately not stored here. */
public class AccountStore {
    public static class Account { public String id,name; Account(String i,String n){id=i;name=n;} }
    private final SharedPreferences prefs;
    public AccountStore(Context c){prefs=c.getSharedPreferences("nexa_accounts",Context.MODE_PRIVATE);}
    public List<Account> all(){
        List<Account> out=new ArrayList<>();
        try { JSONArray a=new JSONArray(prefs.getString("items","[]")); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new Account(o.getString("id"),o.getString("name")));} } catch(Exception ignored){}
        return out;
    }
    public String selected(){return prefs.getString("selected","");}
    public void add(String name){List<Account> a=all();a.add(new Account(UUID.randomUUID().toString(),name));write(a);if(selected().isEmpty())select(a.get(a.size()-1).id);}
    public void select(String id){prefs.edit().putString("selected",id).apply();}
    public void remove(String id){List<Account>a=all();for(int i=a.size()-1;i>=0;i--)if(a.get(i).id.equals(id))a.remove(i);write(a);if(selected().equals(id))select(a.isEmpty()?"":a.get(0).id);}
    private void write(List<Account>a){JSONArray j=new JSONArray();try{for(Account x:a){JSONObject o=new JSONObject();o.put("id",x.id);o.put("name",x.name);j.put(o);}}catch(Exception ignored){}prefs.edit().putString("items",j.toString()).apply();}
}
