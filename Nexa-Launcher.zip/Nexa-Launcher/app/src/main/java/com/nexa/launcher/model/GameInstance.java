package com.nexa.launcher.model;

import org.json.JSONException;
import org.json.JSONObject;

public class GameInstance {
    public String id;
    public String name;
    public String version;
    public String channel;
    public String accountId;

    public GameInstance(String id, String name, String version, String channel, String accountId) {
        this.id=id; this.name=name; this.version=version; this.channel=channel; this.accountId=accountId;
    }
    public JSONObject toJson() throws JSONException {
        JSONObject o=new JSONObject(); o.put("id",id); o.put("name",name); o.put("version",version);
        o.put("channel",channel); o.put("accountId",accountId); return o;
    }
    public static GameInstance fromJson(JSONObject o) throws JSONException {
        return new GameInstance(o.getString("id"),o.getString("name"),o.optString("version","1.21.114"),o.optString("channel","release"),o.optString("accountId",""));
    }
}
