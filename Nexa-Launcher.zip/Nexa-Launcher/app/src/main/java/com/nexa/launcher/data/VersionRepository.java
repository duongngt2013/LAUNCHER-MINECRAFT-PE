package com.nexa.launcher.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VersionRepository {
    public static class Version { public String number,channel,date,changelog; Version(String n,String c,String d,String l){number=n;channel=c;date=d;changelog=l;} }
    public interface Callback { void done(List<Version> versions,String error); }
    private final SharedPreferences prefs;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    public VersionRepository(Context c){prefs=c.getSharedPreferences("nexa_versions",Context.MODE_PRIVATE);}
    public String source(){return prefs.getString("manifest_url","");}
    public void setSource(String url){prefs.edit().putString("manifest_url",url.trim()).apply();}
    public List<Version> cached(){return parse(prefs.getString("cache","{}"));}
    public void refresh(Callback cb){
        final String endpoint=source();
        if(endpoint.isEmpty()){cb.done(cached(),"Chưa cấu hình URL manifest phiên bản.");return;}
        worker.execute(()->{
            HttpURLConnection c=null;
            try{
                URL u=new URL(endpoint); if(!"https".equalsIgnoreCase(u.getProtocol()))throw new Exception("Chỉ chấp nhận nguồn HTTPS.");
                c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","NexaLauncher/0.2");
                int code=c.getResponseCode();if(code<200||code>=300)throw new Exception("Máy chủ trả về HTTP "+code);
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();
                JSONObject root=new JSONObject(b.toString());if(root.optInt("schema",1)!=1)throw new Exception("Manifest schema không được hỗ trợ.");
                List<Version> list=parse(b.toString());prefs.edit().putString("cache",b.toString()).apply();cb.done(list,null);
            }catch(Exception e){cb.done(cached(),e.getMessage()==null?"Không thể đồng bộ phiên bản.":e.getMessage());}
            finally{if(c!=null)c.disconnect();}
        });
    }
    private List<Version> parse(String json){
        List<Version> out=new ArrayList<>();try{JSONObject root=new JSONObject(json);JSONArray a=root.optJSONArray("versions");if(a==null)return out;
            for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String v=o.optString("version","");String ch=o.optString("channel","").toLowerCase();if(v.isEmpty()||(!ch.equals("release")&&!ch.equals("beta")))continue;if(compare(v,"1.21.114")<0)continue;out.add(new Version(v,ch,o.optString("releasedAt",""),o.optString("changelogUrl","")));}
            Collections.sort(out,(x,y)->compare(y.number,x.number));
        }catch(Exception ignored){}return out;
    }
    private static int compare(String a,String b){
        String[] x=a.split("[.-]"),y=b.split("[.-]");int n=Math.max(x.length,y.length);
        for(int i=0;i<n;i++){long p=i<x.length?number(x[i]):0,q=i<y.length?number(y[i]):0;if(p!=q)return p<q?-1:1;}
        return 0;
    }
    private static long number(String s){try{return Long.parseLong(s.replaceAll("[^0-9]",""));}catch(Exception e){return 0;}}
}
